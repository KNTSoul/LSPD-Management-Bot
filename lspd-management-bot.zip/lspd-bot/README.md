# LSPD Management Bot

Production-ready Discord.js v14 bot for managing an LSPD (roleplay police department)
Discord server: dynamic rank hierarchy, reports, traffic citations, shift tracking,
announcements — all configurable entirely from Discord via `/setup`, with MongoDB
persistence and automatic state restoration after a restart.

## Features

- **`/setup`** — fully interactive, in-Discord configuration wizard (no config files, no restarts):
  - Rank hierarchy (add/remove/reorder roles as ranks)
  - Log / Report / Citation / Shift / Announcement channels
  - Moderator & Administrator roles
  - Language (Turkish / English)
  - Default settings (fine currency, rank-down reason requirement, shift reminder, max shift length)
- **Dynamic rank system** — `/rankup` and `/rankdown` detect the member's current rank role
  automatically and move them to the next/previous rank **in whatever order is currently
  configured**. Reordering ranks in `/setup` immediately changes how promotions/demotions behave —
  zero code changes, zero restarts.
- **Reports** — `/report file|view|resolve|list`, posted to the configured report channel with
  case numbers, status tracking (open/in review/resolved/dismissed), and full history.
- **Traffic citations** — `/citation issue|void|history`, auto-numbered, posted to the configured
  citation channel, with per-member fine history and totals.
- **Shift tracking** — `/shift start|end|status|leaderboard`, with weekly leaderboard aggregation.
- **Announcements** — `/announce` posts a formatted embed to the configured announcement channel.
- **Full audit logging** — every rank change, report, citation, and shift action is posted to the
  configured log channel.
- **Permission system** — native Discord Administrator, configured Administrator/Moderator roles,
  and optional per-command role overrides, all enforced consistently across every command.
- **MongoDB persistence** — all configuration and data survive restarts automatically; nothing is
  held only in memory except a 30-second read cache that self-invalidates on every write.

## Requirements

- Node.js 18.17+
- A MongoDB database (Atlas free tier works fine)
- A Discord application + bot token with the **Server Members Intent** enabled in the
  [Developer Portal](https://discord.com/developers/applications) → Bot → Privileged Gateway Intents.

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```
2. Copy `.env.example` to `.env` and fill in the values:
   ```bash
   cp .env.example .env
   ```
   - `DISCORD_TOKEN` — your bot's token
   - `CLIENT_ID` — your application's client ID
   - `MONGODB_URI` — your MongoDB connection string
   - `DEV_GUILD_ID` — (optional) a guild ID for instant command registration while developing
   - `OWNER_IDS` — (optional) comma-separated Discord user IDs that bypass all permission checks
3. Register slash commands:
   ```bash
   npm run deploy
   ```
4. Start the bot:
   ```bash
   npm start
   ```
   Use `npm run dev` during development for auto-restart on file changes (requires `nodemon`,
   already listed in devDependencies).

## First-time configuration

1. Invite the bot to your server with the `applications.commands` and `bot` scopes, and at minimum
   the **Manage Roles**, **View Channels**, and **Send Messages** bot permissions. The bot's role
   must sit **above** every rank role in the server's role list, or it will not be able to assign them.
2. Run `/setup` as a server administrator.
3. Configure, in any order:
   - **Rütbe Hiyerarşisi** — add every LSPD rank role from lowest to highest. Use the reorder
     buttons to fine-tune the order at any time; `/rankup` and `/rankdown` will immediately follow
     the new order.
   - **Kanallar** — set the log, report, citation, shift, and announcement channels.
   - **Roller** — set moderator and administrator roles.
   - **Dil** and **Varsayılan Ayarlar** as desired.
4. Click **Kurulumu Tamamla** on the main menu when finished.

## Project structure

```
src/
  config/            env loading + shared constants
  database/           mongoose connection, models, cached config service
  events/             discord.js event listeners (ready, interactionCreate)
  handlers/           command/event auto-loaders
  commands/
    setup/            /setup
    ranks/             /rankup /rankdown /rank-info
    reports/           /report
    citations/         /citation
    shifts/            /shift
    admin/             /announce /config-view
    general/           /help
  utils/              embeds, permissions, rank logic, setup wizard, logging
  deploy-commands.js  slash command registration script
  index.js            bot entry point
```

## Notes on the rank system

Ranks are stored as an ordered array (`GuildConfig.ranks`, sorted by `order`, ascending from
lowest to highest). `/rankup` and `/rankdown` never hardcode rank names — they read a member's
Discord roles, find the highest-index configured rank role the member holds, and move them one
step up or down that array. Adding, removing, or reordering ranks in `/setup` takes effect
immediately for every future promotion/demotion.
