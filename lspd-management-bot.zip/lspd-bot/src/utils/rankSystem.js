'use strict';

/**
 * The rank hierarchy is fully data-driven: guildConfig.ranks is an array of
 * { roleId, name, order } sorted ascending by `order` (0 = lowest rank).
 * Nothing here hardcodes rank names or counts — changing the order in the
 * setup wizard immediately changes what rankup/rankdown do, with zero code
 * changes required.
 */

function getSortedRanks(guildConfig) {
  return [...(guildConfig?.ranks || [])].sort((a, b) => a.order - b.order);
}

/**
 * Determines a member's current position in the configured hierarchy by
 * scanning their roles against the ordered rank list. If a member holds
 * multiple configured rank roles (misconfiguration or manual role edits),
 * the HIGHEST one is treated as their current rank.
 *
 * @returns {{ index: number, rank: object } | null} null if member holds no configured rank role.
 */
function getCurrentRank(member, guildConfig) {
  const ranks = getSortedRanks(guildConfig);
  let best = null;
  let bestIndex = -1;

  ranks.forEach((rank, index) => {
    if (member.roles.cache.has(rank.roleId) && index > bestIndex) {
      best = rank;
      bestIndex = index;
    }
  });

  if (!best) return null;
  return { index: bestIndex, rank: best };
}

/**
 * Computes the result of a rank-up or rank-down operation without mutating
 * Discord state. Returns a descriptive result object; the caller applies
 * the actual role add/remove.
 *
 * @param {'up'|'down'} direction
 */
function computeRankTransition(member, guildConfig, direction) {
  const ranks = getSortedRanks(guildConfig);

  if (ranks.length === 0) {
    return { ok: false, code: 'NO_HIERARCHY' };
  }

  const current = getCurrentRank(member, guildConfig);

  if (!current) {
    // Member holds no configured rank yet — rank up assigns the lowest rank,
    // rank down is not meaningful (nothing to demote from).
    if (direction === 'up') {
      return { ok: true, code: 'ASSIGNED_FIRST', from: null, to: ranks[0], toIndex: 0 };
    }
    return { ok: false, code: 'NO_CURRENT_RANK' };
  }

  const targetIndex = direction === 'up' ? current.index + 1 : current.index - 1;

  if (targetIndex < 0) {
    return { ok: false, code: 'ALREADY_LOWEST', from: current.rank };
  }

  if (targetIndex >= ranks.length) {
    return { ok: false, code: 'ALREADY_HIGHEST', from: current.rank };
  }

  return {
    ok: true,
    code: 'TRANSITIONED',
    from: current.rank,
    to: ranks[targetIndex],
    toIndex: targetIndex,
  };
}

module.exports = {
  getSortedRanks,
  getCurrentRank,
  computeRankTransition,
};
