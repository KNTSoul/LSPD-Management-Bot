'use strict';

const { PermissionFlagsBits } = require('discord.js');
const { OWNER_IDS } = require('../config/env');

/**
 * True if the member is the guild owner, a configured bot owner, or holds
 * the native Discord Administrator permission.
 */
function isServerAdministrator(member) {
  if (!member) return false;
  if (OWNER_IDS.includes(member.id)) return true;
  if (member.guild?.ownerId === member.id) return true;
  return member.permissions.has(PermissionFlagsBits.Administrator);
}

/**
 * True if the member holds any role listed in roleIds.
 */
function hasAnyRole(member, roleIds = []) {
  if (!member || !Array.isArray(roleIds) || roleIds.length === 0) return false;
  return roleIds.some((roleId) => member.roles.cache.has(roleId));
}

/**
 * True if the member is configured as an LSPD administrator (config.roles.adminRoles)
 * or is a native server administrator.
 */
function isConfiguredAdmin(member, guildConfig) {
  if (isServerAdministrator(member)) return true;
  return hasAnyRole(member, guildConfig?.roles?.adminRoles);
}

/**
 * True if the member is a moderator OR admin per config, or a native admin.
 */
function isConfiguredModerator(member, guildConfig) {
  if (isConfiguredAdmin(member, guildConfig)) return true;
  return hasAnyRole(member, guildConfig?.roles?.moderatorRoles);
}

/**
 * Checks a per-command permission override stored in guildConfig.commandPermissions.
 * If no override exists for the command, falls back to the provided defaultCheck.
 *
 * @param {string} commandName
 * @param {GuildMember} member
 * @param {object} guildConfig - mongoose document or plain object
 * @param {(member, guildConfig) => boolean} defaultCheck
 */
function canRunCommand(commandName, member, guildConfig, defaultCheck) {
  if (isServerAdministrator(member)) return true;

  const overrides = guildConfig?.commandPermissions;
  const overrideRoles = overrides instanceof Map ? overrides.get(commandName) : overrides?.[commandName];

  if (Array.isArray(overrideRoles) && overrideRoles.length > 0) {
    return hasAnyRole(member, overrideRoles);
  }

  return defaultCheck(member, guildConfig);
}

module.exports = {
  isServerAdministrator,
  hasAnyRole,
  isConfiguredAdmin,
  isConfiguredModerator,
  canRunCommand,
};
