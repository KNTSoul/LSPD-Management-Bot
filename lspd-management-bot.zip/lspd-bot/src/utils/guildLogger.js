'use strict';

const { baseEmbed } = require('./embeds');
const { COLORS } = require('../config/env');
const logger = require('./logger');

/**
 * Sends an audit embed to the guild's configured log channel, if set and
 * still accessible. Never throws — logging failures must never break the
 * feature that triggered them.
 *
 * @param {Guild} guild
 * @param {object} guildConfig
 * @param {{ title: string, description: string, fields?: Array, color?: number }} payload
 */
async function logToGuildChannel(guild, guildConfig, payload) {
  const channelId = guildConfig?.channels?.logChannel;
  if (!channelId) return;

  try {
    const channel = await guild.channels.fetch(channelId).catch(() => null);
    if (!channel || !channel.isTextBased()) return;

    const embed = baseEmbed({ color: payload.color || COLORS.PRIMARY })
      .setTitle(payload.title)
      .setDescription(payload.description || null);

    if (payload.fields?.length) embed.addFields(payload.fields);

    await channel.send({ embeds: [embed] });
  } catch (err) {
    logger.warn('GuildLogger', `Log kanalına yazılamadı (guild: ${guild.id}): ${err.message}`);
  }
}

module.exports = { logToGuildChannel };
