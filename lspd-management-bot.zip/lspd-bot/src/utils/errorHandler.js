'use strict';

const { errorEmbed } = require('./embeds');
const logger = require('./logger');

/**
 * Wraps a command/interaction handler so any thrown error is logged and the
 * user always gets a clean embed response instead of a silent failure or a
 * raw Discord "This interaction failed" message.
 */
async function safeExecute(interaction, fn, context = 'Command') {
  try {
    await fn();
  } catch (err) {
    logger.error(context, `${err.stack || err.message}`);

    const payload = {
      embeds: [errorEmbed('Bir Hata Oluştu', 'İşlem sırasında beklenmeyen bir hata oluştu. Bu durum kaydedildi.')],
      ephemeral: true,
    };

    try {
      if (interaction.deferred || interaction.replied) {
        await interaction.followUp(payload);
      } else {
        await interaction.reply(payload);
      }
    } catch (nestedErr) {
      logger.error(context, `Hata mesajı gönderilemedi: ${nestedErr.message}`);
    }
  }
}

module.exports = { safeExecute };
