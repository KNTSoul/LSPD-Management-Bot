'use strict';

const { EmbedBuilder } = require('discord.js');
const { COLORS } = require('../config/env');

const FOOTER_TEXT = 'LSPD Management System';

function baseEmbed({ color = COLORS.PRIMARY, author = null } = {}) {
  const embed = new EmbedBuilder().setColor(color).setTimestamp().setFooter({ text: FOOTER_TEXT });
  if (author) embed.setAuthor(author);
  return embed;
}

function successEmbed(title, description) {
  return baseEmbed({ color: COLORS.SUCCESS }).setTitle(`✅ ${title}`).setDescription(description);
}

function errorEmbed(title, description) {
  return baseEmbed({ color: COLORS.DANGER }).setTitle(`⛔ ${title}`).setDescription(description);
}

function warningEmbed(title, description) {
  return baseEmbed({ color: COLORS.WARNING }).setTitle(`⚠️ ${title}`).setDescription(description);
}

function infoEmbed(title, description) {
  return baseEmbed({ color: COLORS.PRIMARY }).setTitle(`ℹ️ ${title}`).setDescription(description);
}

module.exports = {
  baseEmbed,
  successEmbed,
  errorEmbed,
  warningEmbed,
  infoEmbed,
  FOOTER_TEXT,
};
