'use strict';

const COLORS = {
  reset: '\x1b[0m',
  gray: '\x1b[90m',
  cyan: '\x1b[36m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
};

function timestamp() {
  return new Date().toISOString();
}

function line(color, level, scope, message) {
  // eslint-disable-next-line no-console
  console.log(`${COLORS.gray}[${timestamp()}]${COLORS.reset} ${color}${level}${COLORS.reset} ${COLORS.cyan}[${scope}]${COLORS.reset} ${message}`);
}

const logger = {
  info(scope, message) {
    line(COLORS.cyan, 'INFO ', scope, message);
  },
  success(scope, message) {
    line(COLORS.green, 'OK   ', scope, message);
  },
  warn(scope, message) {
    line(COLORS.yellow, 'WARN ', scope, message);
  },
  error(scope, message) {
    line(COLORS.red, 'ERROR', scope, message);
  },
};

module.exports = logger;
