'use strict';

const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const { baseEmbed, errorEmbed } = require('./embeds');
const { COLORS } = require('../config/env');
const {
  CHANNEL_TYPES,
  CHANNEL_LABELS,
  ROLE_GROUPS,
  ROLE_GROUP_LABELS,
  SUPPORTED_LANGUAGES,
  MAX_RANKS,
  OVERRIDABLE_COMMANDS,
} = require('../config/constants');
const { getGuildConfig, updateGuildConfig } = require('../database/guildConfigService');
const { isConfiguredAdmin } = require('./permissions');
const { getSortedRanks } = require('./rankSystem');

const LANGUAGE_LABELS = { tr: '🇹🇷 Türkçe', en: '🇬🇧 English' };

// ---------------------------------------------------------------------------
// View builders — each returns { embeds, components }
// ---------------------------------------------------------------------------

function buildMainMenu(guildConfig) {
  const ranks = getSortedRanks(guildConfig);
  const ch = guildConfig.channels || {};
  const configuredChannels = Object.values(CHANNEL_TYPES).filter((t) => ch[t]).length;
  const modCount = guildConfig.roles?.moderatorRoles?.length || 0;
  const adminCount = guildConfig.roles?.adminRoles?.length || 0;
  const overridesMap = guildConfig.commandPermissions;
  const overrideCount = overridesMap instanceof Map ? overridesMap.size : Object.keys(overridesMap || {}).length;

  const embed = baseEmbed({ color: COLORS.PRIMARY })
    .setTitle('🛠️ LSPD Kurulum Sihirbazı')
    .setDescription(
      'Botu tamamen Discord içinden yapılandırın. Aşağıdaki menüden bir kategori seçin.\n\n' +
        `**Rütbe Hiyerarşisi:** ${ranks.length} rütbe tanımlı\n` +
        `**Kanallar:** ${configuredChannels}/${Object.values(CHANNEL_TYPES).length} ayarlandı\n` +
        `**Roller:** ${modCount} moderatör rolü, ${adminCount} yönetici rolü\n` +
        `**Komut İzinleri:** ${overrideCount} özel yetki tanımlı\n` +
        `**Dil:** ${LANGUAGE_LABELS[guildConfig.language] || guildConfig.language}\n` +
        `**Kurulum Durumu:** ${guildConfig.setupCompleted ? '✅ Tamamlandı' : '⏳ Devam ediyor'}`
    );

  const select = new StringSelectMenuBuilder()
    .setCustomId('setup_menu')
    .setPlaceholder('Bir kategori seçin...')
    .addOptions(
      { label: 'Rütbe Hiyerarşisi', description: 'LSPD rütbe sırasını oluştur/düzenle', value: 'ranks', emoji: '🎖️' },
      { label: 'Kanallar', description: 'Log, rapor, ceza, mesai, duyuru kanalları', value: 'channels', emoji: '📁' },
      { label: 'Roller', description: 'Moderatör ve yönetici rolleri', value: 'roles', emoji: '👮' },
      { label: 'Dil', description: 'Bot arayüz dili', value: 'language', emoji: '🌐' },
      { label: 'Komut İzinleri', description: 'Belirli komutlar için özel rol yetkileri', value: 'permissions', emoji: '🔐' },
      { label: 'Varsayılan Ayarlar', description: 'Para birimi, mesai limiti ve daha fazlası', value: 'defaults', emoji: '⚙️' },
      { label: 'Kurulumu Tamamla', description: 'Yapılandırmayı tamamlandı olarak işaretle', value: 'finish', emoji: '✅' }
    );

  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(select)] };
}

function buildRanksView(guildConfig, selectedRoleId = null) {
  const ranks = getSortedRanks(guildConfig);

  const listText = ranks.length
    ? ranks
        .map((r, i) => `**${ranks.length - i}.** <@&${r.roleId}> — \`${r.name}\``)
        .reverse()
        .join('\n')
    : '_Henüz rütbe tanımlanmadı. Aşağıdan bir rol seçerek en üst rütbe olarak ekleyin._';

  const embed = baseEmbed({ color: COLORS.PRIMARY })
    .setTitle('🎖️ Rütbe Hiyerarşisi')
    .setDescription(
      `${listText}\n\n` +
        '_Liste en yüksek rütbe üstte, en düşük rütbe altta gösterilir. Rank Up/Down komutları bu sırayı otomatik olarak takip eder._'
    );

  const rows = [];

  const addRow = new ActionRowBuilder().addComponents(
    new RoleSelectMenuBuilder()
      .setCustomId('setup_ranks_add')
      .setPlaceholder(ranks.length >= MAX_RANKS ? 'Maksimum rütbe sayısına ulaşıldı' : 'Yeni rütbe eklemek için rol seç')
      .setMinValues(1)
      .setMaxValues(1)
      .setDisabled(ranks.length >= MAX_RANKS)
  );
  rows.push(addRow);

  if (ranks.length > 0) {
    const pickSelect = new StringSelectMenuBuilder()
      .setCustomId('setup_ranks_pick')
      .setPlaceholder('Sırayı düzenlemek veya silmek için bir rütbe seç')
      .addOptions(
        ranks
          .map((r) => ({
            label: r.name.slice(0, 100),
            value: r.roleId,
            description: `Sıra: ${r.order + 1}`,
            default: r.roleId === selectedRoleId,
          }))
          .slice(0, 25)
      );
    rows.push(new ActionRowBuilder().addComponents(pickSelect));

    if (selectedRoleId) {
      const idx = ranks.findIndex((r) => r.roleId === selectedRoleId);
      rows.push(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`setup_ranks_up_${selectedRoleId}`)
            .setLabel('Yukarı Taşı')
            .setEmoji('⬆️')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(idx >= ranks.length - 1),
          new ButtonBuilder()
            .setCustomId(`setup_ranks_down_${selectedRoleId}`)
            .setLabel('Aşağı Taşı')
            .setEmoji('⬇️')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(idx <= 0),
          new ButtonBuilder()
            .setCustomId(`setup_ranks_remove_${selectedRoleId}`)
            .setLabel('Sil')
            .setEmoji('🗑️')
            .setStyle(ButtonStyle.Danger)
        )
      );
    }
  }

  rows.push(
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('setup_back').setLabel('Ana Menüye Dön').setStyle(ButtonStyle.Secondary).setEmoji('◀️')
    )
  );

  return { embeds: [embed], components: rows.slice(0, 5) };
}

function buildChannelsMenuView(guildConfig) {
  const ch = guildConfig.channels || {};
  const embed = baseEmbed({ color: COLORS.PRIMARY })
    .setTitle('📁 Kanal Ayarları')
    .setDescription(
      Object.values(CHANNEL_TYPES)
        .map((type) => `**${CHANNEL_LABELS[type]}:** ${ch[type] ? `<#${ch[type]}>` : '_ayarlanmadı_'}`)
        .join('\n')
    );

  const select = new StringSelectMenuBuilder()
    .setCustomId('setup_channels_pick')
    .setPlaceholder('Ayarlanacak kanalı seçin...')
    .addOptions(Object.values(CHANNEL_TYPES).map((type) => ({ label: CHANNEL_LABELS[type], value: type })));

  const backRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('setup_back').setLabel('Ana Menüye Dön').setStyle(ButtonStyle.Secondary).setEmoji('◀️')
  );

  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(select), backRow] };
}

function buildChannelSetView(guildConfig, type) {
  const ch = guildConfig.channels || {};
  const embed = baseEmbed({ color: COLORS.PRIMARY })
    .setTitle(`📁 ${CHANNEL_LABELS[type]}`)
    .setDescription(`Mevcut: ${ch[type] ? `<#${ch[type]}>` : '_ayarlanmadı_'}\n\nAşağıdan yeni bir metin kanalı seçin.`);

  const channelSelect = new ChannelSelectMenuBuilder()
    .setCustomId(`setup_channel_set_${type}`)
    .setPlaceholder('Bir kanal seçin...')
    .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
    .setMinValues(1)
    .setMaxValues(1);

  const backRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('setup_channels_back').setLabel('Kanal Menüsüne Dön').setStyle(ButtonStyle.Secondary).setEmoji('◀️'),
    new ButtonBuilder().setCustomId('setup_back').setLabel('Ana Menü').setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(channelSelect), backRow] };
}

function buildRolesMenuView(guildConfig) {
  const mod = guildConfig.roles?.moderatorRoles || [];
  const admin = guildConfig.roles?.adminRoles || [];

  const embed = baseEmbed({ color: COLORS.PRIMARY })
    .setTitle('👮 Rol Ayarları')
    .setDescription(
      `**${ROLE_GROUP_LABELS[ROLE_GROUPS.MODERATOR]}:** ${mod.length ? mod.map((r) => `<@&${r}>`).join(', ') : '_ayarlanmadı_'}\n` +
        `**${ROLE_GROUP_LABELS[ROLE_GROUPS.ADMIN]}:** ${admin.length ? admin.map((r) => `<@&${r}>`).join(', ') : '_ayarlanmadı_'}\n\n` +
        '_Yönetici rolleri otomatik olarak moderatör yetkilerini de kapsar. Sunucu "Yönetici" izinine sahip üyeler her zaman tam yetkilidir._'
    );

  const select = new StringSelectMenuBuilder()
    .setCustomId('setup_roles_pick')
    .setPlaceholder('Düzenlenecek rol grubunu seçin...')
    .addOptions(
      { label: ROLE_GROUP_LABELS[ROLE_GROUPS.MODERATOR], value: ROLE_GROUPS.MODERATOR },
      { label: ROLE_GROUP_LABELS[ROLE_GROUPS.ADMIN], value: ROLE_GROUPS.ADMIN }
    );

  const backRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('setup_back').setLabel('Ana Menüye Dön').setStyle(ButtonStyle.Secondary).setEmoji('◀️')
  );

  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(select), backRow] };
}

function buildRoleSetView(guildConfig, group) {
  const current = guildConfig.roles?.[group] || [];
  const embed = baseEmbed({ color: COLORS.PRIMARY })
    .setTitle(`👮 ${ROLE_GROUP_LABELS[group]}`)
    .setDescription(
      `Mevcut: ${current.length ? current.map((r) => `<@&${r}>`).join(', ') : '_ayarlanmadı_'}\n\n` +
        'Aşağıdan bir veya birden fazla rol seçin. Seçiminiz mevcut listenin **yerine geçer**.'
    );

  const roleSelect = new RoleSelectMenuBuilder()
    .setCustomId(`setup_role_set_${group}`)
    .setPlaceholder('Rol(ler) seçin...')
    .setMinValues(1)
    .setMaxValues(10);

  const backRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('setup_roles_back').setLabel('Rol Menüsüne Dön').setStyle(ButtonStyle.Secondary).setEmoji('◀️'),
    new ButtonBuilder().setCustomId('setup_back').setLabel('Ana Menü').setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(roleSelect), backRow] };
}

function buildPermissionsMenuView(guildConfig) {
  const overrides = guildConfig.commandPermissions;
  const getRoles = (cmd) => (overrides instanceof Map ? overrides.get(cmd) : overrides?.[cmd]) || [];

  const embed = baseEmbed({ color: COLORS.PRIMARY })
    .setTitle('🔐 Komut İzinleri')
    .setDescription(
      Object.entries(OVERRIDABLE_COMMANDS)
        .map(([cmd, label]) => {
          const roles = getRoles(cmd);
          return `**${label}:** ${roles.length ? roles.map((r) => `<@&${r}>`).join(', ') : '_varsayılan (moderatör/yönetici)_'}`;
        })
        .join('\n') +
        '\n\n_Bir komut için özel rol tanımlarsanız, o komut yalnızca o roller (ve yöneticiler) tarafından çalıştırılabilir. Boş bırakılırsa varsayılan yetki kuralı geçerlidir._'
    );

  const select = new StringSelectMenuBuilder()
    .setCustomId('setup_perms_pick')
    .setPlaceholder('Düzenlenecek komutu seçin...')
    .addOptions(Object.entries(OVERRIDABLE_COMMANDS).map(([cmd, label]) => ({ label, value: cmd })));

  const backRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('setup_back').setLabel('Ana Menüye Dön').setStyle(ButtonStyle.Secondary).setEmoji('◀️')
  );

  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(select), backRow] };
}

function buildPermissionSetView(guildConfig, commandName) {
  const overrides = guildConfig.commandPermissions;
  const current = (overrides instanceof Map ? overrides.get(commandName) : overrides?.[commandName]) || [];

  const embed = baseEmbed({ color: COLORS.PRIMARY })
    .setTitle(`🔐 ${OVERRIDABLE_COMMANDS[commandName]}`)
    .setDescription(
      `Mevcut özel yetki: ${current.length ? current.map((r) => `<@&${r}>`).join(', ') : '_yok (varsayılan kural geçerli)_'}\n\n` +
        'Rol seçerek bu komut için özel yetki tanımlayın, ya da "Varsayılana Sıfırla" butonuyla kaldırın.'
    );

  const roleSelect = new RoleSelectMenuBuilder()
    .setCustomId(`setup_perms_set_${commandName}`)
    .setPlaceholder('Rol(ler) seçin...')
    .setMinValues(1)
    .setMaxValues(10);

  const buttonsRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`setup_perms_clear_${commandName}`).setLabel('Varsayılana Sıfırla').setStyle(ButtonStyle.Danger).setEmoji('♻️'),
    new ButtonBuilder().setCustomId('setup_perms_back').setLabel('Komut Listesine Dön').setStyle(ButtonStyle.Secondary).setEmoji('◀️'),
    new ButtonBuilder().setCustomId('setup_back').setLabel('Ana Menü').setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(roleSelect), buttonsRow] };
}

function buildLanguageView(guildConfig) {
  const embed = baseEmbed({ color: COLORS.PRIMARY })
    .setTitle('🌐 Dil Ayarı')
    .setDescription(`Mevcut dil: **${LANGUAGE_LABELS[guildConfig.language] || guildConfig.language}**`);

  const select = new StringSelectMenuBuilder()
    .setCustomId('setup_language_set')
    .setPlaceholder('Dil seçin...')
    .addOptions(SUPPORTED_LANGUAGES.map((lang) => ({ label: LANGUAGE_LABELS[lang], value: lang, default: lang === guildConfig.language })));

  const backRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('setup_back').setLabel('Ana Menüye Dön').setStyle(ButtonStyle.Secondary).setEmoji('◀️')
  );

  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(select), backRow] };
}

function buildDefaultsView(guildConfig) {
  const s = guildConfig.settings || {};
  const embed = baseEmbed({ color: COLORS.PRIMARY })
    .setTitle('⚙️ Varsayılan Ayarlar')
    .setDescription(
      `**Para Birimi:** ${s.defaultFineCurrency}\n` +
        `**Rütbe Düşürmede Sebep Zorunlu:** ${s.requireReasonOnRankDown ? 'Evet' : 'Hayır'}\n` +
        `**Mesai Hatırlatma (dk):** ${s.shiftReminderMinutes || 0} ${s.shiftReminderMinutes ? '' : '(kapalı)'}\n` +
        `**Maksimum Aktif Mesai (saat):** ${s.maxActiveShiftHours}\n\n` +
        'Değerleri güncellemek için aşağıdaki butona basın.'
    );

  const rows = [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('setup_defaults_modal').setLabel('Ayarları Düzenle').setStyle(ButtonStyle.Primary).setEmoji('✏️')
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('setup_back').setLabel('Ana Menüye Dön').setStyle(ButtonStyle.Secondary).setEmoji('◀️')
    ),
  ];

  return { embeds: [embed], components: rows };
}

function buildDefaultsModal(guildConfig) {
  const s = guildConfig.settings || {};
  const modal = new ModalBuilder().setCustomId('setup_defaults_submit').setTitle('Varsayılan Ayarlar');

  const currencyInput = new TextInputBuilder()
    .setCustomId('currency')
    .setLabel('Para birimi sembolü (örn: $, ₺)')
    .setStyle(TextInputStyle.Short)
    .setValue(s.defaultFineCurrency || '$')
    .setMaxLength(5)
    .setRequired(true);

  const reasonRequiredInput = new TextInputBuilder()
    .setCustomId('requireReason')
    .setLabel('Rütbe düşürmede sebep zorunlu mu? (evet/hayir)')
    .setStyle(TextInputStyle.Short)
    .setValue(s.requireReasonOnRankDown ? 'evet' : 'hayir')
    .setMaxLength(5)
    .setRequired(true);

  const reminderInput = new TextInputBuilder()
    .setCustomId('shiftReminder')
    .setLabel('Mesai hatırlatma süresi (dk, 0=kapalı)')
    .setStyle(TextInputStyle.Short)
    .setValue(String(s.shiftReminderMinutes ?? 0))
    .setMaxLength(4)
    .setRequired(true);

  const maxShiftInput = new TextInputBuilder()
    .setCustomId('maxShiftHours')
    .setLabel('Maksimum aktif mesai süresi (saat)')
    .setStyle(TextInputStyle.Short)
    .setValue(String(s.maxActiveShiftHours ?? 12))
    .setMaxLength(3)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(currencyInput),
    new ActionRowBuilder().addComponents(reasonRequiredInput),
    new ActionRowBuilder().addComponents(reminderInput),
    new ActionRowBuilder().addComponents(maxShiftInput)
  );

  return modal;
}

// ---------------------------------------------------------------------------
// Router — handles every component/modal interaction whose customId starts
// with "setup_" or "setup" prefixed variants.
// ---------------------------------------------------------------------------

async function guardAdmin(interaction, guildConfig) {
  if (isConfiguredAdmin(interaction.member, guildConfig)) return true;
  await interaction.reply({
    embeds: [errorEmbed('Yetkiniz Yok', 'Bu paneli yalnızca yöneticiler kullanabilir.')],
    ephemeral: true,
  });
  return false;
}

async function handleInteraction(interaction) {
  const guildId = interaction.guildId;
  if (!guildId) return;

  let guildConfig = await getGuildConfig(guildId);
  if (!(await guardAdmin(interaction, guildConfig))) return;

  const id = interaction.customId;

  // --- Main menu navigation -------------------------------------------------
  if (interaction.isStringSelectMenu() && id === 'setup_menu') {
    const value = interaction.values[0];
    if (value === 'ranks') return interaction.update(buildRanksView(guildConfig));
    if (value === 'channels') return interaction.update(buildChannelsMenuView(guildConfig));
    if (value === 'roles') return interaction.update(buildRolesMenuView(guildConfig));
    if (value === 'language') return interaction.update(buildLanguageView(guildConfig));
    if (value === 'permissions') return interaction.update(buildPermissionsMenuView(guildConfig));
    if (value === 'defaults') return interaction.update(buildDefaultsView(guildConfig));
    if (value === 'finish') {
      guildConfig = await updateGuildConfig(guildId, (doc) => {
        doc.setupCompleted = true;
      });
      return interaction.update(buildMainMenu(guildConfig));
    }
  }

  if (id === 'setup_back') return interaction.update(buildMainMenu(guildConfig));

  // --- Ranks -----------------------------------------------------------------
  if (interaction.isRoleSelectMenu() && id === 'setup_ranks_add') {
    const role = interaction.roles.first();
    const ranks = getSortedRanks(guildConfig);

    if (ranks.some((r) => r.roleId === role.id)) {
      return interaction.reply({ embeds: [errorEmbed('Zaten Ekli', 'Bu rol zaten hiyerarşide tanımlı.')], ephemeral: true });
    }
    if (ranks.length >= MAX_RANKS) {
      return interaction.reply({ embeds: [errorEmbed('Limit Aşıldı', `En fazla ${MAX_RANKS} rütbe tanımlanabilir.`)], ephemeral: true });
    }

    guildConfig = await updateGuildConfig(guildId, (doc) => {
      doc.ranks.push({ roleId: role.id, name: role.name, order: doc.ranks.length });
    });
    return interaction.update(buildRanksView(guildConfig));
  }

  if (interaction.isStringSelectMenu() && id === 'setup_ranks_pick') {
    return interaction.update(buildRanksView(guildConfig, interaction.values[0]));
  }

  if (interaction.isButton() && id.startsWith('setup_ranks_up_')) {
    const roleId = id.replace('setup_ranks_up_', '');
    guildConfig = await updateGuildConfig(guildId, (doc) => {
      swapRankOrder(doc, roleId, 1);
    });
    return interaction.update(buildRanksView(guildConfig, roleId));
  }

  if (interaction.isButton() && id.startsWith('setup_ranks_down_')) {
    const roleId = id.replace('setup_ranks_down_', '');
    guildConfig = await updateGuildConfig(guildId, (doc) => {
      swapRankOrder(doc, roleId, -1);
    });
    return interaction.update(buildRanksView(guildConfig, roleId));
  }

  if (interaction.isButton() && id.startsWith('setup_ranks_remove_')) {
    const roleId = id.replace('setup_ranks_remove_', '');
    guildConfig = await updateGuildConfig(guildId, (doc) => {
      doc.ranks = doc.ranks.filter((r) => r.roleId !== roleId);
      doc.ranks.sort((a, b) => a.order - b.order).forEach((r, i) => {
        r.order = i;
      });
    });
    return interaction.update(buildRanksView(guildConfig));
  }

  // --- Channels ----------------------------------------------------------
  if (interaction.isStringSelectMenu() && id === 'setup_channels_pick') {
    return interaction.update(buildChannelSetView(guildConfig, interaction.values[0]));
  }

  if (id === 'setup_channels_back') return interaction.update(buildChannelsMenuView(guildConfig));

  if (interaction.isChannelSelectMenu() && id.startsWith('setup_channel_set_')) {
    const type = id.replace('setup_channel_set_', '');
    const channelId = interaction.values[0];
    guildConfig = await updateGuildConfig(guildId, (doc) => {
      doc.channels[type] = channelId;
    });
    return interaction.update(buildChannelSetView(guildConfig, type));
  }

  // --- Roles ---------------------------------------------------------------
  if (interaction.isStringSelectMenu() && id === 'setup_roles_pick') {
    return interaction.update(buildRoleSetView(guildConfig, interaction.values[0]));
  }

  if (id === 'setup_roles_back') return interaction.update(buildRolesMenuView(guildConfig));

  if (interaction.isRoleSelectMenu() && id.startsWith('setup_role_set_')) {
    const group = id.replace('setup_role_set_', '');
    const roleIds = interaction.values;
    guildConfig = await updateGuildConfig(guildId, (doc) => {
      doc.roles[group] = roleIds;
    });
    return interaction.update(buildRoleSetView(guildConfig, group));
  }

  // --- Language ------------------------------------------------------------
  if (interaction.isStringSelectMenu() && id === 'setup_language_set') {
    const lang = interaction.values[0];
    guildConfig = await updateGuildConfig(guildId, (doc) => {
      doc.language = lang;
    });
    return interaction.update(buildLanguageView(guildConfig));
  }

  // --- Command permissions --------------------------------------------------
  if (interaction.isStringSelectMenu() && id === 'setup_perms_pick') {
    return interaction.update(buildPermissionSetView(guildConfig, interaction.values[0]));
  }

  if (id === 'setup_perms_back') return interaction.update(buildPermissionsMenuView(guildConfig));

  if (interaction.isRoleSelectMenu() && id.startsWith('setup_perms_set_')) {
    const commandName = id.replace('setup_perms_set_', '');
    const roleIds = interaction.values;
    guildConfig = await updateGuildConfig(guildId, (doc) => {
      doc.commandPermissions.set(commandName, roleIds);
    });
    return interaction.update(buildPermissionSetView(guildConfig, commandName));
  }

  if (interaction.isButton() && id.startsWith('setup_perms_clear_')) {
    const commandName = id.replace('setup_perms_clear_', '');
    guildConfig = await updateGuildConfig(guildId, (doc) => {
      doc.commandPermissions.delete(commandName);
    });
    return interaction.update(buildPermissionSetView(guildConfig, commandName));
  }

  // --- Defaults --------------------------------------------------------------
  if (interaction.isButton() && id === 'setup_defaults_modal') {
    return interaction.showModal(buildDefaultsModal(guildConfig));
  }

  if (interaction.isModalSubmit() && id === 'setup_defaults_submit') {
    const currency = interaction.fields.getTextInputValue('currency').trim() || '$';
    const requireReasonRaw = interaction.fields.getTextInputValue('requireReason').trim().toLowerCase();
    const reminderRaw = interaction.fields.getTextInputValue('shiftReminder').trim();
    const maxShiftRaw = interaction.fields.getTextInputValue('maxShiftHours').trim();

    const reminderMinutes = Number.parseInt(reminderRaw, 10);
    const maxShiftHours = Number.parseInt(maxShiftRaw, 10);

    if (!Number.isFinite(reminderMinutes) || reminderMinutes < 0 || reminderMinutes > 1440) {
      return interaction.reply({
        embeds: [errorEmbed('Geçersiz Değer', 'Mesai hatırlatma süresi 0-1440 arasında bir sayı olmalıdır.')],
        ephemeral: true,
      });
    }
    if (!Number.isFinite(maxShiftHours) || maxShiftHours < 1 || maxShiftHours > 48) {
      return interaction.reply({
        embeds: [errorEmbed('Geçersiz Değer', 'Maksimum mesai süresi 1-48 saat arasında olmalıdır.')],
        ephemeral: true,
      });
    }

    guildConfig = await updateGuildConfig(guildId, (doc) => {
      doc.settings.defaultFineCurrency = currency;
      doc.settings.requireReasonOnRankDown = requireReasonRaw === 'evet' || requireReasonRaw === 'yes';
      doc.settings.shiftReminderMinutes = reminderMinutes;
      doc.settings.maxActiveShiftHours = maxShiftHours;
    });

    return interaction.update(buildDefaultsView(guildConfig));
  }
}

function swapRankOrder(doc, roleId, delta) {
  const ranks = doc.ranks.sort((a, b) => a.order - b.order);
  const idx = ranks.findIndex((r) => r.roleId === roleId);
  const targetIdx = idx + (delta > 0 ? 1 : -1);
  if (idx === -1 || targetIdx < 0 || targetIdx >= ranks.length) return;

  const a = ranks[idx];
  const b = ranks[targetIdx];
  const tmp = a.order;
  a.order = b.order;
  b.order = tmp;
}

module.exports = {
  buildMainMenu,
  handleInteraction,
};
