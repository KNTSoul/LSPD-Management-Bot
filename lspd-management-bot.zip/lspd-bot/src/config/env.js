'use strict';

require('dotenv').config();

const required = ['DISCORD_TOKEN', 'CLIENT_ID', 'MONGODB_URI'];
const missing = required.filter((key) => !process.env[key] || process.env[key].trim() === '');

if (missing.length > 0) {
  // Fail fast and loudly — a partially configured bot is worse than one that refuses to boot.
  // eslint-disable-next-line no-console
  console.error(`[FATAL] Missing required environment variables: ${missing.join(', ')}`);
  process.exit(1);
}

const parseOwnerIds = (raw) =>
  (raw || '')
    .split(',')
    .map((id) => id.trim())
    .filter(Boolean);

module.exports = {
  DISCORD_TOKEN: process.env.DISCORD_TOKEN,
  CLIENT_ID: process.env.CLIENT_ID,
  DEV_GUILD_ID: process.env.DEV_GUILD_ID || null,
  MONGODB_URI: process.env.MONGODB_URI,
  OWNER_IDS: parseOwnerIds(process.env.OWNER_IDS),
  COLORS: {
    PRIMARY: parseInt(process.env.COLOR_PRIMARY || '1F2A44', 16),
    SUCCESS: parseInt(process.env.COLOR_SUCCESS || '2ECC71', 16),
    DANGER: parseInt(process.env.COLOR_DANGER || 'E74C3C', 16),
    WARNING: parseInt(process.env.COLOR_WARNING || 'F5A623', 16),
  },
};
