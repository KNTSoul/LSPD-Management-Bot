'use strict';

/**
 * Central place for enums / static configuration used across the bot.
 * Nothing environment-specific lives here — see src/config/env.js for that.
 */

const CHANNEL_TYPES = Object.freeze({
  LOG: 'logChannel',
  REPORT: 'reportChannel',
  CITATION: 'citationChannel',
  SHIFT: 'shiftChannel',
  ANNOUNCEMENT: 'announcementChannel',
});

const CHANNEL_LABELS = Object.freeze({
  [CHANNEL_TYPES.LOG]: 'Log Kanalı',
  [CHANNEL_TYPES.REPORT]: 'Rapor Kanalı',
  [CHANNEL_TYPES.CITATION]: 'Trafik Cezası Kanalı',
  [CHANNEL_TYPES.SHIFT]: 'Mesai Kanalı',
  [CHANNEL_TYPES.ANNOUNCEMENT]: 'Duyuru Kanalı',
});

const ROLE_GROUPS = Object.freeze({
  MODERATOR: 'moderatorRoles',
  ADMIN: 'adminRoles',
});

const ROLE_GROUP_LABELS = Object.freeze({
  [ROLE_GROUPS.MODERATOR]: 'Moderatör Rolleri',
  [ROLE_GROUPS.ADMIN]: 'Yönetici Rolleri',
});

const LANGUAGES = Object.freeze({
  TR: 'tr',
  EN: 'en',
});

const SUPPORTED_LANGUAGES = [LANGUAGES.TR, LANGUAGES.EN];

const REPORT_STATUS = Object.freeze({
  OPEN: 'open',
  IN_REVIEW: 'in_review',
  RESOLVED: 'resolved',
  DISMISSED: 'dismissed',
});

const SETUP_STAGES = Object.freeze({
  MAIN_MENU: 'main_menu',
  RANKS: 'ranks',
  CHANNELS: 'channels',
  ROLES: 'roles',
  LANGUAGE: 'language',
  DEFAULTS: 'defaults',
});

// In-memory setup wizard session TTL (ms). Sessions auto-expire so a stale
// wizard message can never be used to silently mutate config later.
const SETUP_SESSION_TTL_MS = 10 * 60 * 1000;

const MAX_RANKS = 25;

// Commands that support a per-guild role-based permission override via
// /setup → Komut İzinleri. Keys must match the `canRunCommand(commandName, ...)`
// calls made inside each command file.
const OVERRIDABLE_COMMANDS = Object.freeze({
  rankup: 'Rütbe Yükseltme (/rankup)',
  rankdown: 'Rütbe Düşürme (/rankdown)',
  'report-resolve': 'Rapor Sonuçlandırma (/report resolve)',
  'citation-issue': 'Ceza Kesme (/citation issue)',
  'citation-void': 'Ceza İptal Etme (/citation void)',
  announce: 'Duyuru Gönderme (/announce)',
});

module.exports = {
  CHANNEL_TYPES,
  CHANNEL_LABELS,
  ROLE_GROUPS,
  ROLE_GROUP_LABELS,
  LANGUAGES,
  SUPPORTED_LANGUAGES,
  REPORT_STATUS,
  SETUP_STAGES,
  SETUP_SESSION_TTL_MS,
  MAX_RANKS,
  OVERRIDABLE_COMMANDS,
};
