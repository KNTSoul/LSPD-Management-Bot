'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig } = require('../../database/guildConfigService');
const { canRunCommand, isConfiguredAdmin } = require('../../utils/permissions');
const { baseEmbed, successEmbed, errorEmbed } = require('../../utils/embeds');
const { COLORS } = require('../../config/env');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('announce')
    .setDescription('Yapılandırılmış duyuru kanalına resmi bir duyuru gönderir.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false)
    .addStringOption((opt) => opt.setName('baslik').setDescription('Duyuru başlığı').setRequired(true))
    .addStringOption((opt) => opt.setName('mesaj').setDescription('Duyuru içeriği').setRequired(true))
    .addBooleanOption((opt) => opt.setName('herkese-etiket').setDescription('@everyone ile etiketle').setRequired(false)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);

    if (!canRunCommand('announce', interaction.member, guildConfig, isConfiguredAdmin)) {
      return interaction.reply({
        embeds: [errorEmbed('Yetkiniz Yok', 'Bu komutu yalnızca yöneticiler kullanabilir.')],
        ephemeral: true,
      });
    }

    if (!guildConfig.channels?.announcementChannel) {
      return interaction.reply({
        embeds: [errorEmbed('Kanal Ayarlanmadı', 'Duyuru kanalı henüz yapılandırılmadı. `/setup` komutuyla ayarlayın.')],
        ephemeral: true,
      });
    }

    const title = interaction.options.getString('baslik', true);
    const message = interaction.options.getString('mesaj', true);
    const mentionEveryone = interaction.options.getBoolean('herkese-etiket') || false;

    const channel = await interaction.guild.channels.fetch(guildConfig.channels.announcementChannel).catch(() => null);
    if (!channel?.isTextBased()) {
      return interaction.reply({
        embeds: [errorEmbed('Kanal Bulunamadı', 'Yapılandırılmış duyuru kanalına erişilemiyor. `/setup` ile yeniden ayarlayın.')],
        ephemeral: true,
      });
    }

    const embed = baseEmbed({ color: COLORS.PRIMARY })
      .setTitle(`📢 ${title}`)
      .setDescription(message)
      .setFooter({ text: `Duyuran: ${interaction.user.tag}` });

    await channel.send({ content: mentionEveryone ? '@everyone' : undefined, embeds: [embed] });

    await interaction.reply({ embeds: [successEmbed('Duyuru Gönderildi', `Duyurunuz ${channel} kanalına başarıyla gönderildi.`)], ephemeral: true });
  },
};
