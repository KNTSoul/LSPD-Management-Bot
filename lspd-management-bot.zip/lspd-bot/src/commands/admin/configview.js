'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig } = require('../../database/guildConfigService');
const { getSortedRanks } = require('../../utils/rankSystem');
const { isConfiguredAdmin } = require('../../utils/permissions');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { COLORS } = require('../../config/env');
const { CHANNEL_TYPES, CHANNEL_LABELS } = require('../../config/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('config-view')
    .setDescription('Sunucunun mevcut bot yapılandırmasını görüntüler.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);

    if (!isConfiguredAdmin(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed('Yetkiniz Yok', 'Bu komutu yalnızca yöneticiler kullanabilir.')], ephemeral: true });
    }

    const ranks = getSortedRanks(guildConfig);
    const rankList = ranks.length
      ? [...ranks].reverse().map((r, i) => `${ranks.length - i}. <@&${r.roleId}>`).join('\n')
      : '_Tanımlanmadı_';

    const channelList = Object.values(CHANNEL_TYPES)
      .map((type) => `**${CHANNEL_LABELS[type]}:** ${guildConfig.channels?.[type] ? `<#${guildConfig.channels[type]}>` : '_ayarlanmadı_'}`)
      .join('\n');

    const modRoles = guildConfig.roles?.moderatorRoles?.length ? guildConfig.roles.moderatorRoles.map((r) => `<@&${r}>`).join(', ') : '_yok_';
    const adminRoles = guildConfig.roles?.adminRoles?.length ? guildConfig.roles.adminRoles.map((r) => `<@&${r}>`).join(', ') : '_yok_';

    const embed = baseEmbed({ color: COLORS.PRIMARY })
      .setTitle('⚙️ Sunucu Yapılandırması')
      .addFields(
        { name: '🎖️ Rütbe Hiyerarşisi (yüksekten düşüğe)', value: rankList },
        { name: '📁 Kanallar', value: channelList },
        { name: '👮 Moderatör Rolleri', value: modRoles },
        { name: '👑 Yönetici Rolleri', value: adminRoles },
        { name: '🌐 Dil', value: guildConfig.language, inline: true },
        { name: '💰 Para Birimi', value: guildConfig.settings?.defaultFineCurrency || '$', inline: true },
        { name: '⏱️ Maks. Mesai (saat)', value: String(guildConfig.settings?.maxActiveShiftHours ?? 12), inline: true },
        { name: '✅ Kurulum Durumu', value: guildConfig.setupCompleted ? 'Tamamlandı' : 'Devam ediyor', inline: true }
      );

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
