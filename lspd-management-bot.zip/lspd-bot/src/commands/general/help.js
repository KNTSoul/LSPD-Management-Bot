'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { COLORS } = require('../../config/env');

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('Botun tüm komutlarını ve kullanımlarını gösterir.').setDMPermission(false),

  async execute(interaction) {
    const embed = baseEmbed({ color: COLORS.PRIMARY })
      .setTitle('📖 LSPD Management Bot — Komutlar')
      .setDescription('Aşağıda tüm komut kategorileri ve kullanımları listelenmiştir.')
      .addFields(
        {
          name: '🛠️ Yönetim',
          value: '`/setup` — Botu yapılandır\n`/config-view` — Mevcut yapılandırmayı görüntüle\n`/announce` — Duyuru gönder',
        },
        {
          name: '🎖️ Rütbe Sistemi',
          value: '`/rankup` — Üyeyi terfi ettir\n`/rankdown` — Üyeyi düşür\n`/rank-info` — Rütbe bilgisini görüntüle',
        },
        {
          name: '📋 Raporlar',
          value: '`/report file` — Rapor oluştur\n`/report view` — Rapor görüntüle\n`/report resolve` — Raporu sonuçlandır\n`/report list` — Raporları listele',
        },
        {
          name: '🚨 Trafik Cezaları',
          value: '`/citation issue` — Ceza kes\n`/citation void` — Cezayı iptal et\n`/citation history` — Ceza geçmişini görüntüle',
        },
        {
          name: '🕐 Mesai Sistemi',
          value: '`/shift start` — Mesaiye başla\n`/shift end` — Mesaiyi bitir\n`/shift status` — Mesai durumunu görüntüle\n`/shift leaderboard` — Haftalık sıralama',
        }
      );

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
