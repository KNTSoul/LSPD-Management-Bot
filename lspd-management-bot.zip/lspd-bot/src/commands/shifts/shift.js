'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig } = require('../../database/guildConfigService');
const Shift = require('../../database/models/Shift');
const { successEmbed, errorEmbed, infoEmbed, baseEmbed } = require('../../utils/embeds');
const { COLORS } = require('../../config/env');
const { logToGuildChannel } = require('../../utils/guildLogger');

function formatDuration(ms) {
  const totalMinutes = Math.floor(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${hours}s ${minutes}dk`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shift')
    .setDescription('Mesai (görev) sürenizi yönetin.')
    .setDMPermission(false)
    .addSubcommand((sub) => sub.setName('start').setDescription('Mesaiyi başlat.'))
    .addSubcommand((sub) => sub.setName('end').setDescription('Mesaiyi bitir.'))
    .addSubcommand((sub) =>
      sub
        .setName('status')
        .setDescription('Bir üyenin mesai durumunu görüntüle.')
        .addUserOption((opt) => opt.setName('uye').setDescription('Üye (boş bırakılırsa kendiniz)').setRequired(false))
    )
    .addSubcommand((sub) => sub.setName('leaderboard').setDescription('Bu haftaki en çok mesai yapan üyeleri gösterir.')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'start') return this.startShift(interaction);
    if (sub === 'end') return this.endShift(interaction);
    if (sub === 'status') return this.statusShift(interaction);
    if (sub === 'leaderboard') return this.leaderboardShift(interaction);
  },

  async startShift(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);

    const existing = await Shift.findOne({ guildId: interaction.guildId, userId: interaction.user.id, active: true });
    if (existing) {
      return interaction.reply({
        embeds: [errorEmbed('Zaten Aktif', 'Zaten devam eden bir mesainiz var. Önce `/shift end` ile bitirin.')],
        ephemeral: true,
      });
    }

    const shift = await Shift.create({
      guildId: interaction.guildId,
      userId: interaction.user.id,
      startTime: new Date(),
      active: true,
    });

    const embed = successEmbed('Mesai Başladı', `${interaction.user} mesaiye başladı. İyi görevler!`);

    let sentMessageId = null;
    let sentChannelId = null;

    if (guildConfig.channels?.shiftChannel) {
      const channel = await interaction.guild.channels.fetch(guildConfig.channels.shiftChannel).catch(() => null);
      if (channel?.isTextBased()) {
        const sent = await channel.send({ embeds: [embed] });
        sentMessageId = sent.id;
        sentChannelId = channel.id;
      }
    }

    shift.messageId = sentMessageId;
    shift.channelId = sentChannelId;
    await shift.save();

    await interaction.reply({ embeds: [embed], ephemeral: !guildConfig.channels?.shiftChannel });
  },

  async endShift(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);

    const shift = await Shift.findOne({ guildId: interaction.guildId, userId: interaction.user.id, active: true });
    if (!shift) {
      return interaction.reply({ embeds: [errorEmbed('Aktif Mesai Yok', 'Devam eden bir mesainiz bulunmuyor.')], ephemeral: true });
    }

    shift.endTime = new Date();
    shift.durationMs = shift.endTime.getTime() - shift.startTime.getTime();
    shift.active = false;
    await shift.save();

    const embed = successEmbed(
      'Mesai Bitti',
      `${interaction.user} mesaiyi sonlandırdı.\n**Süre:** ${formatDuration(shift.durationMs)}`
    );

    await interaction.reply({ embeds: [embed] });

    await logToGuildChannel(interaction.guild, guildConfig, {
      title: '🕐 Mesai Tamamlandı',
      description: `${interaction.user} — ${formatDuration(shift.durationMs)}`,
      color: COLORS.PRIMARY,
    });
  },

  async statusShift(interaction) {
    const targetUser = interaction.options.getUser('uye') || interaction.user;
    const active = await Shift.findOne({ guildId: interaction.guildId, userId: targetUser.id, active: true });

    const completedShifts = await Shift.find({ guildId: interaction.guildId, userId: targetUser.id, active: false });
    const totalMs = completedShifts.reduce((sum, s) => sum + s.durationMs, 0);

    const embed = infoEmbed(
      `Mesai Durumu — ${targetUser.username}`,
      active
        ? `🟢 **Aktif mesai** — <t:${Math.floor(active.startTime.getTime() / 1000)}:R> başladı.`
        : '🔴 Şu anda aktif bir mesai yok.'
    ).addFields(
      { name: 'Toplam Tamamlanan Mesai', value: `${completedShifts.length}`, inline: true },
      { name: 'Toplam Süre', value: formatDuration(totalMs), inline: true }
    );

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },

  async leaderboardShift(interaction) {
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

    const shifts = await Shift.find({
      guildId: interaction.guildId,
      active: false,
      createdAt: { $gte: oneWeekAgo },
    });

    if (shifts.length === 0) {
      return interaction.reply({ embeds: [infoEmbed('Veri Yok', 'Bu hafta için tamamlanmış mesai kaydı bulunamadı.')], ephemeral: true });
    }

    const totals = new Map();
    for (const s of shifts) {
      totals.set(s.userId, (totals.get(s.userId) || 0) + s.durationMs);
    }

    const sorted = [...totals.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10);

    const embed = baseEmbed({ color: COLORS.PRIMARY })
      .setTitle('🏆 Haftalık Mesai Sıralaması')
      .setDescription(sorted.map(([userId, ms], i) => `**${i + 1}.** <@${userId}> — ${formatDuration(ms)}`).join('\n'));

    return interaction.reply({ embeds: [embed] });
  },
};
