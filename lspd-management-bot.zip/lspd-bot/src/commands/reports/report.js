'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig } = require('../../database/guildConfigService');
const { getNextSequence } = require('../../database/models/Counter');
const Report = require('../../database/models/Report');
const { canRunCommand, isConfiguredModerator } = require('../../utils/permissions');
const { baseEmbed, successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { COLORS } = require('../../config/env');
const { REPORT_STATUS } = require('../../config/constants');
const { logToGuildChannel } = require('../../utils/guildLogger');

const STATUS_LABELS = {
  [REPORT_STATUS.OPEN]: '🟡 Açık',
  [REPORT_STATUS.IN_REVIEW]: '🔵 İnceleniyor',
  [REPORT_STATUS.RESOLVED]: '🟢 Çözüldü',
  [REPORT_STATUS.DISMISSED]: '⚪ Reddedildi',
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('report')
    .setDescription('LSPD üyeleri hakkında rapor oluşturun veya yönetin.')
    .setDMPermission(false)
    .addSubcommand((sub) =>
      sub
        .setName('file')
        .setDescription('Bir üye hakkında yeni rapor oluştur.')
        .addUserOption((opt) => opt.setName('uye').setDescription('Rapor edilecek üye').setRequired(true))
        .addStringOption((opt) => opt.setName('sebep').setDescription('Rapor sebebi').setRequired(true))
        .addStringOption((opt) => opt.setName('kanit').setDescription('Kanıt linki (opsiyonel)').setRequired(false))
    )
    .addSubcommand((sub) =>
      sub
        .setName('view')
        .setDescription('Belirli bir raporu görüntüle.')
        .addIntegerOption((opt) => opt.setName('numara').setDescription('Rapor numarası').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('resolve')
        .setDescription('Bir raporu sonuçlandır (sadece moderatör/yönetici).')
        .addIntegerOption((opt) => opt.setName('numara').setDescription('Rapor numarası').setRequired(true))
        .addStringOption((opt) =>
          opt
            .setName('durum')
            .setDescription('Yeni durum')
            .setRequired(true)
            .addChoices(
              { name: 'İnceleniyor', value: REPORT_STATUS.IN_REVIEW },
              { name: 'Çözüldü', value: REPORT_STATUS.RESOLVED },
              { name: 'Reddedildi', value: REPORT_STATUS.DISMISSED }
            )
        )
        .addStringOption((opt) => opt.setName('not').setDescription('Sonuç notu').setRequired(false))
    )
    .addSubcommand((sub) =>
      sub
        .setName('list')
        .setDescription('Raporları listele.')
        .addUserOption((opt) => opt.setName('uye').setDescription('Belirli bir üyenin raporları').setRequired(false))
        .addStringOption((opt) =>
          opt
            .setName('durum')
            .setDescription('Duruma göre filtrele')
            .setRequired(false)
            .addChoices(
              { name: 'Açık', value: REPORT_STATUS.OPEN },
              { name: 'İnceleniyor', value: REPORT_STATUS.IN_REVIEW },
              { name: 'Çözüldü', value: REPORT_STATUS.RESOLVED },
              { name: 'Reddedildi', value: REPORT_STATUS.DISMISSED }
            )
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'file') return this.fileReport(interaction);
    if (sub === 'view') return this.viewReport(interaction);
    if (sub === 'resolve') return this.resolveReport(interaction);
    if (sub === 'list') return this.listReports(interaction);
  },

  async fileReport(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const targetUser = interaction.options.getUser('uye', true);
    const reasonText = interaction.options.getString('sebep', true);
    const evidence = interaction.options.getString('kanit');

    if (targetUser.id === interaction.user.id) {
      return interaction.reply({ embeds: [errorEmbed('Geçersiz İşlem', 'Kendiniz hakkında rapor oluşturamazsınız.')], ephemeral: true });
    }

    const caseNumber = await getNextSequence(`${interaction.guildId}:report`);

    const report = await Report.create({
      guildId: interaction.guildId,
      caseNumber,
      reporterId: interaction.user.id,
      targetId: targetUser.id,
      reason: reasonText,
      evidence: evidence || null,
    });

    const embed = baseEmbed({ color: COLORS.WARNING })
      .setTitle(`📋 Rapor #${caseNumber}`)
      .setDescription(`**Hedef:** <@${targetUser.id}>\n**Bildiren:** ${interaction.user}\n**Durum:** ${STATUS_LABELS[report.status]}`)
      .addFields({ name: 'Sebep', value: reasonText });

    if (evidence) embed.addFields({ name: 'Kanıt', value: evidence });

    let postedMessageId = null;
    let postedChannelId = null;

    if (guildConfig.channels?.reportChannel) {
      const channel = await interaction.guild.channels.fetch(guildConfig.channels.reportChannel).catch(() => null);
      if (channel?.isTextBased()) {
        const sent = await channel.send({ embeds: [embed] });
        postedMessageId = sent.id;
        postedChannelId = channel.id;
      }
    }

    report.messageId = postedMessageId;
    report.channelId = postedChannelId;
    await report.save();

    await interaction.reply({
      embeds: [successEmbed('Rapor Oluşturuldu', `Rapor #${caseNumber} başarıyla oluşturuldu.`)],
      ephemeral: true,
    });

    await logToGuildChannel(interaction.guild, guildConfig, {
      title: '📋 Yeni Rapor',
      description: `Rapor #${caseNumber} — <@${targetUser.id}> hakkında ${interaction.user} tarafından oluşturuldu.`,
      color: COLORS.WARNING,
    });
  },

  async viewReport(interaction) {
    const caseNumber = interaction.options.getInteger('numara', true);
    const report = await Report.findOne({ guildId: interaction.guildId, caseNumber });

    if (!report) {
      return interaction.reply({ embeds: [errorEmbed('Bulunamadı', `#${caseNumber} numaralı rapor bulunamadı.`)], ephemeral: true });
    }

    const embed = infoEmbed(
      `Rapor #${report.caseNumber}`,
      `**Hedef:** <@${report.targetId}>\n**Bildiren:** <@${report.reporterId}>\n**Durum:** ${STATUS_LABELS[report.status]}`
    ).addFields({ name: 'Sebep', value: report.reason });

    if (report.evidence) embed.addFields({ name: 'Kanıt', value: report.evidence });
    if (report.resolutionNote) {
      embed.addFields({
        name: 'Sonuç Notu',
        value: `${report.resolutionNote}\n_Sonuçlandıran: <@${report.resolvedById}>_`,
      });
    }

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },

  async resolveReport(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);

    if (!canRunCommand('report-resolve', interaction.member, guildConfig, isConfiguredModerator)) {
      return interaction.reply({
        embeds: [errorEmbed('Yetkiniz Yok', 'Bu işlemi yalnızca moderatör veya yönetici rolüne sahip üyeler yapabilir.')],
        ephemeral: true,
      });
    }

    const caseNumber = interaction.options.getInteger('numara', true);
    const status = interaction.options.getString('durum', true);
    const note = interaction.options.getString('not');

    const report = await Report.findOne({ guildId: interaction.guildId, caseNumber });
    if (!report) {
      return interaction.reply({ embeds: [errorEmbed('Bulunamadı', `#${caseNumber} numaralı rapor bulunamadı.`)], ephemeral: true });
    }

    report.status = status;
    report.resolvedById = interaction.user.id;
    report.resolutionNote = note || null;
    await report.save();

    if (report.messageId && report.channelId) {
      const channel = await interaction.guild.channels.fetch(report.channelId).catch(() => null);
      if (channel?.isTextBased()) {
        const msg = await channel.messages.fetch(report.messageId).catch(() => null);
        if (msg) {
          const embed = baseEmbed({ color: COLORS.PRIMARY })
            .setTitle(`📋 Rapor #${report.caseNumber}`)
            .setDescription(`**Hedef:** <@${report.targetId}>\n**Bildiren:** <@${report.reporterId}>\n**Durum:** ${STATUS_LABELS[status]}`)
            .addFields({ name: 'Sebep', value: report.reason });
          if (report.evidence) embed.addFields({ name: 'Kanıt', value: report.evidence });
          if (note) embed.addFields({ name: 'Sonuç Notu', value: `${note}\n_Sonuçlandıran: ${interaction.user}_` });
          await msg.edit({ embeds: [embed] }).catch(() => null);
        }
      }
    }

    await interaction.reply({
      embeds: [successEmbed('Rapor Güncellendi', `Rapor #${caseNumber} durumu **${STATUS_LABELS[status]}** olarak güncellendi.`)],
      ephemeral: true,
    });

    await logToGuildChannel(interaction.guild, guildConfig, {
      title: '📋 Rapor Sonuçlandırıldı',
      description: `Rapor #${caseNumber} → ${STATUS_LABELS[status]} (${interaction.user})`,
    });
  },

  async listReports(interaction) {
    const targetUser = interaction.options.getUser('uye');
    const status = interaction.options.getString('durum');

    const query = { guildId: interaction.guildId };
    if (targetUser) query.targetId = targetUser.id;
    if (status) query.status = status;

    const reports = await Report.find(query).sort({ createdAt: -1 }).limit(15);

    if (reports.length === 0) {
      return interaction.reply({ embeds: [infoEmbed('Rapor Bulunamadı', 'Kriterlere uyan rapor bulunamadı.')], ephemeral: true });
    }

    const embed = infoEmbed(
      'Rapor Listesi',
      reports
        .map((r) => `**#${r.caseNumber}** <@${r.targetId}> — ${STATUS_LABELS[r.status]} _(<t:${Math.floor(r.createdAt.getTime() / 1000)}:R>)_`)
        .join('\n')
    );

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
