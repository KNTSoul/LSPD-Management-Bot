'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig } = require('../../database/guildConfigService');
const { computeRankTransition } = require('../../utils/rankSystem');
const { canRunCommand, isConfiguredModerator } = require('../../utils/permissions');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { logToGuildChannel } = require('../../utils/guildLogger');
const RankHistory = require('../../database/models/RankHistory');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rankup')
    .setDescription('Bir üyeyi yapılandırılmış LSPD hiyerarşisinde bir üst rütbeye terfi ettirir.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false)
    .addUserOption((opt) => opt.setName('uye').setDescription('Terfi edilecek üye').setRequired(true))
    .addStringOption((opt) => opt.setName('sebep').setDescription('Terfi sebebi (opsiyonel)').setRequired(false)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);

    if (!canRunCommand('rankup', interaction.member, guildConfig, isConfiguredModerator)) {
      return interaction.reply({
        embeds: [errorEmbed('Yetkiniz Yok', 'Bu komutu kullanmak için moderatör veya yönetici rolüne sahip olmalısınız.')],
        ephemeral: true,
      });
    }

    const targetUser = interaction.options.getUser('uye', true);
    const reason = interaction.options.getString('sebep') || 'Belirtilmedi';

    const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
    if (!targetMember) {
      return interaction.reply({ embeds: [errorEmbed('Üye Bulunamadı', 'Belirtilen kullanıcı bu sunucuda bulunamadı.')], ephemeral: true });
    }

    const result = computeRankTransition(targetMember, guildConfig, 'up');

    if (!result.ok) {
      const messages = {
        NO_HIERARCHY: 'Bu sunucuda henüz bir rütbe hiyerarşisi tanımlanmadı. `/setup` komutuyla yapılandırın.',
        ALREADY_HIGHEST: `${targetMember} zaten en yüksek rütbede (**${result.from?.name}**).`,
      };
      return interaction.reply({
        embeds: [errorEmbed('Terfi Yapılamadı', messages[result.code] || 'Bilinmeyen bir hata oluştu.')],
        ephemeral: true,
      });
    }

    try {
      if (result.from) await targetMember.roles.remove(result.from.roleId).catch(() => null);
      await targetMember.roles.add(result.to.roleId);
    } catch (err) {
      logger.error('RankUp', `Rol güncellenemedi: ${err.message}`);
      return interaction.reply({
        embeds: [errorEmbed('Rol Hatası', 'Rütbe rolü verilirken bir hata oluştu. Botun rol hiyerarşisini kontrol edin.')],
        ephemeral: true,
      });
    }

    await RankHistory.create({
      guildId: interaction.guildId,
      targetId: targetMember.id,
      actorId: interaction.user.id,
      direction: 'up',
      fromRoleId: result.from?.roleId || null,
      toRoleId: result.to.roleId,
      fromRankName: result.from?.name || null,
      toRankName: result.to.name,
      reason,
    });

    const embed = successEmbed(
      'Terfi Gerçekleşti',
      `${targetMember} rütbesi ${result.from ? `**${result.from.name}** rütbesinden ` : ''}**${result.to.name}** rütbesine yükseltildi.`
    ).addFields(
      { name: 'Yetkili', value: `${interaction.user}`, inline: true },
      { name: 'Sebep', value: reason, inline: true }
    );

    await interaction.reply({ embeds: [embed] });

    await logToGuildChannel(interaction.guild, guildConfig, {
      title: '🎖️ Rütbe Terfisi',
      description: `${targetMember} → **${result.to.name}**`,
      fields: [
        { name: 'Önceki Rütbe', value: result.from?.name || '—', inline: true },
        { name: 'Yeni Rütbe', value: result.to.name, inline: true },
        { name: 'Yetkili', value: `${interaction.user}`, inline: true },
        { name: 'Sebep', value: reason, inline: false },
      ],
    });
  },
};
