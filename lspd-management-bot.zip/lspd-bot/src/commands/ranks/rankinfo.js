'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig } = require('../../database/guildConfigService');
const { getCurrentRank, getSortedRanks } = require('../../utils/rankSystem');
const { infoEmbed, errorEmbed } = require('../../utils/embeds');
const RankHistory = require('../../database/models/RankHistory');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank-info')
    .setDescription('Bir üyenin mevcut rütbesini ve rütbe geçmişini gösterir.')
    .setDMPermission(false)
    .addUserOption((opt) => opt.setName('uye').setDescription('Görüntülenecek üye (boş bırakılırsa kendiniz)').setRequired(false)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const targetUser = interaction.options.getUser('uye') || interaction.user;

    const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
    if (!targetMember) {
      return interaction.reply({ embeds: [errorEmbed('Üye Bulunamadı', 'Belirtilen kullanıcı bu sunucuda bulunamadı.')], ephemeral: true });
    }

    const ranks = getSortedRanks(guildConfig);
    if (ranks.length === 0) {
      return interaction.reply({
        embeds: [errorEmbed('Hiyerarşi Yok', 'Bu sunucuda henüz bir rütbe hiyerarşisi tanımlanmadı.')],
        ephemeral: true,
      });
    }

    const current = getCurrentRank(targetMember, guildConfig);
    const history = await RankHistory.find({ guildId: interaction.guildId, targetId: targetMember.id })
      .sort({ createdAt: -1 })
      .limit(5);

    const embed = infoEmbed(
      `Rütbe Bilgisi — ${targetUser.username}`,
      current
        ? `**Mevcut Rütbe:** ${current.rank.name}\n**Pozisyon:** ${current.index + 1} / ${ranks.length}`
        : '_Bu üye henüz hiyerarşide bir rütbeye sahip değil._'
    );

    if (history.length > 0) {
      embed.addFields({
        name: 'Son Rütbe Değişiklikleri',
        value: history
          .map((h) => {
            const arrow = h.direction === 'up' ? '⬆️' : h.direction === 'down' ? '⬇️' : '➡️';
            return `${arrow} **${h.fromRankName || '—'}** → **${h.toRankName || '—'}** _(<t:${Math.floor(h.createdAt.getTime() / 1000)}:R>)_`;
          })
          .join('\n'),
      });
    }

    embed.setThumbnail(targetUser.displayAvatarURL());
    return interaction.reply({ embeds: [embed] });
  },
};
