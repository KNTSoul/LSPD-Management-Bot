'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig } = require('../../database/guildConfigService');
const { computeRankTransition } = require('../../utils/rankSystem');
const { canRunCommand, isConfiguredModerator } = require('../../utils/permissions');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { logToGuildChannel } = require('../../utils/guildLogger');
const RankHistory = require('../../database/models/RankHistory');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rankdown')
    .setDescription('Bir üyeyi yapılandırılmış LSPD hiyerarşisinde bir alt rütbeye düşürür.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false)
    .addUserOption((opt) => opt.setName('uye').setDescription('Düşürülecek üye').setRequired(true))
    .addStringOption((opt) => opt.setName('sebep').setDescription('Düşürme sebebi').setRequired(false)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);

    if (!canRunCommand('rankdown', interaction.member, guildConfig, isConfiguredModerator)) {
      return interaction.reply({
        embeds: [errorEmbed('Yetkiniz Yok', 'Bu komutu kullanmak için moderatör veya yönetici rolüne sahip olmalısınız.')],
        ephemeral: true,
      });
    }

    const targetUser = interaction.options.getUser('uye', true);
    const reason = interaction.options.getString('sebep');

    if (guildConfig.settings?.requireReasonOnRankDown && !reason) {
      return interaction.reply({
        embeds: [errorEmbed('Sebep Gerekli', 'Bu sunucuda rütbe düşürme işlemleri için bir sebep belirtilmesi zorunludur.')],
        ephemeral: true,
      });
    }

    const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
    if (!targetMember) {
      return interaction.reply({ embeds: [errorEmbed('Üye Bulunamadı', 'Belirtilen kullanıcı bu sunucuda bulunamadı.')], ephemeral: true });
    }

    const result = computeRankTransition(targetMember, guildConfig, 'down');

    if (!result.ok) {
      const messages = {
        NO_HIERARCHY: 'Bu sunucuda henüz bir rütbe hiyerarşisi tanımlanmadı. `/setup` komutuyla yapılandırın.',
        NO_CURRENT_RANK: `${targetMember} hiyerarşide tanımlı bir rütbeye sahip değil.`,
        ALREADY_LOWEST: `${targetMember} zaten en düşük rütbede (**${result.from?.name}**).`,
      };
      return interaction.reply({
        embeds: [errorEmbed('Düşürme Yapılamadı', messages[result.code] || 'Bilinmeyen bir hata oluştu.')],
        ephemeral: true,
      });
    }

    try {
      await targetMember.roles.remove(result.from.roleId).catch(() => null);
      await targetMember.roles.add(result.to.roleId);
    } catch (err) {
      logger.error('RankDown', `Rol güncellenemedi: ${err.message}`);
      return interaction.reply({
        embeds: [errorEmbed('Rol Hatası', 'Rütbe rolü güncellenirken bir hata oluştu. Botun rol hiyerarşisini kontrol edin.')],
        ephemeral: true,
      });
    }

    await RankHistory.create({
      guildId: interaction.guildId,
      targetId: targetMember.id,
      actorId: interaction.user.id,
      direction: 'down',
      fromRoleId: result.from.roleId,
      toRoleId: result.to.roleId,
      fromRankName: result.from.name,
      toRankName: result.to.name,
      reason: reason || 'Belirtilmedi',
    });

    const embed = successEmbed(
      'Rütbe Düşürüldü',
      `${targetMember} rütbesi **${result.from.name}** rütbesinden **${result.to.name}** rütbesine düşürüldü.`
    ).addFields(
      { name: 'Yetkili', value: `${interaction.user}`, inline: true },
      { name: 'Sebep', value: reason || 'Belirtilmedi', inline: true }
    );

    await interaction.reply({ embeds: [embed] });

    await logToGuildChannel(interaction.guild, guildConfig, {
      title: '📉 Rütbe Düşürüldü',
      description: `${targetMember} → **${result.to.name}**`,
      fields: [
        { name: 'Önceki Rütbe', value: result.from.name, inline: true },
        { name: 'Yeni Rütbe', value: result.to.name, inline: true },
        { name: 'Yetkili', value: `${interaction.user}`, inline: true },
        { name: 'Sebep', value: reason || 'Belirtilmedi', inline: false },
      ],
    });
  },
};
