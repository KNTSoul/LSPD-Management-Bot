'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig } = require('../../database/guildConfigService');
const { buildMainMenu } = require('../../utils/setupWizard');
const { isConfiguredAdmin } = require('../../utils/permissions');
const { errorEmbed } = require('../../utils/embeds');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('LSPD botunu Discord içinden yapılandırın (sadece yöneticiler).')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);

    if (!isConfiguredAdmin(interaction.member, guildConfig)) {
      return interaction.reply({
        embeds: [errorEmbed('Yetkiniz Yok', 'Bu komutu yalnızca sunucu yöneticileri kullanabilir.')],
        ephemeral: true,
      });
    }

    const view = buildMainMenu(guildConfig);
    await interaction.reply({ ...view, ephemeral: true });
    logger.info('Setup', `${interaction.user.tag} setup panelini açtı (guild: ${interaction.guildId})`);
  },
};
