'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getGuildConfig } = require('../../database/guildConfigService');
const { getNextSequence } = require('../../database/models/Counter');
const Citation = require('../../database/models/Citation');
const { canRunCommand, isConfiguredModerator } = require('../../utils/permissions');
const { baseEmbed, successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { COLORS } = require('../../config/env');
const { logToGuildChannel } = require('../../utils/guildLogger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('citation')
    .setDescription('Trafik cezası işlemlerini yönetin.')
    .setDMPermission(false)
    .addSubcommand((sub) =>
      sub
        .setName('issue')
        .setDescription('Yeni bir trafik cezası kes.')
        .addUserOption((opt) => opt.setName('uye').setDescription('Ceza kesilecek üye').setRequired(true))
        .addStringOption((opt) => opt.setName('ihlal').setDescription('İhlal / suç').setRequired(true))
        .addNumberOption((opt) => opt.setName('tutar').setDescription('Ceza tutarı').setRequired(true).setMinValue(0))
        .addStringOption((opt) => opt.setName('not').setDescription('Ek notlar (opsiyonel)').setRequired(false))
    )
    .addSubcommand((sub) =>
      sub
        .setName('void')
        .setDescription('Bir trafik cezasını iptal et (sadece moderatör/yönetici).')
        .addIntegerOption((opt) => opt.setName('numara').setDescription('Ceza numarası').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('history')
        .setDescription('Bir üyenin ceza geçmişini görüntüle.')
        .addUserOption((opt) => opt.setName('uye').setDescription('Üye').setRequired(true))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'issue') return this.issueCitation(interaction);
    if (sub === 'void') return this.voidCitation(interaction);
    if (sub === 'history') return this.historyCitation(interaction);
  },

  async issueCitation(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);

    if (!canRunCommand('citation-issue', interaction.member, guildConfig, isConfiguredModerator)) {
      return interaction.reply({
        embeds: [errorEmbed('Yetkiniz Yok', 'Bu işlemi yalnızca moderatör veya yönetici rolüne sahip üyeler yapabilir.')],
        ephemeral: true,
      });
    }

    const targetUser = interaction.options.getUser('uye', true);
    const violation = interaction.options.getString('ihlal', true);
    const fineAmount = interaction.options.getNumber('tutar', true);
    const notes = interaction.options.getString('not');
    const currency = guildConfig.settings?.defaultFineCurrency || '$';

    const citationNumber = await getNextSequence(`${interaction.guildId}:citation`);

    const citation = await Citation.create({
      guildId: interaction.guildId,
      citationNumber,
      officerId: interaction.user.id,
      targetId: targetUser.id,
      violation,
      fineAmount,
      currency,
      notes: notes || null,
    });

    const embed = baseEmbed({ color: COLORS.DANGER })
      .setTitle(`🚨 Trafik Cezası #${citationNumber}`)
      .setDescription(`**Sürücü:** <@${targetUser.id}>\n**Memur:** ${interaction.user}`)
      .addFields(
        { name: 'İhlal', value: violation, inline: true },
        { name: 'Ceza Tutarı', value: `${currency}${fineAmount.toLocaleString()}`, inline: true }
      );

    if (notes) embed.addFields({ name: 'Notlar', value: notes });

    let postedMessageId = null;
    let postedChannelId = null;

    if (guildConfig.channels?.citationChannel) {
      const channel = await interaction.guild.channels.fetch(guildConfig.channels.citationChannel).catch(() => null);
      if (channel?.isTextBased()) {
        const sent = await channel.send({ embeds: [embed] });
        postedMessageId = sent.id;
        postedChannelId = channel.id;
      }
    }

    citation.messageId = postedMessageId;
    citation.channelId = postedChannelId;
    await citation.save();

    await interaction.reply({
      embeds: [successEmbed('Ceza Kesildi', `Trafik cezası #${citationNumber} başarıyla oluşturuldu.`)],
      ephemeral: true,
    });

    await logToGuildChannel(interaction.guild, guildConfig, {
      title: '🚨 Trafik Cezası Kesildi',
      description: `#${citationNumber} — <@${targetUser.id}> — ${currency}${fineAmount.toLocaleString()} (${interaction.user})`,
      color: COLORS.DANGER,
    });
  },

  async voidCitation(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);

    if (!canRunCommand('citation-void', interaction.member, guildConfig, isConfiguredModerator)) {
      return interaction.reply({
        embeds: [errorEmbed('Yetkiniz Yok', 'Bu işlemi yalnızca moderatör veya yönetici rolüne sahip üyeler yapabilir.')],
        ephemeral: true,
      });
    }

    const citationNumber = interaction.options.getInteger('numara', true);
    const citation = await Citation.findOne({ guildId: interaction.guildId, citationNumber });

    if (!citation) {
      return interaction.reply({ embeds: [errorEmbed('Bulunamadı', `#${citationNumber} numaralı ceza bulunamadı.`)], ephemeral: true });
    }
    if (citation.voided) {
      return interaction.reply({ embeds: [errorEmbed('Zaten İptal Edilmiş', `#${citationNumber} numaralı ceza zaten iptal edilmiş.`)], ephemeral: true });
    }

    citation.voided = true;
    citation.voidedById = interaction.user.id;
    await citation.save();

    if (citation.messageId && citation.channelId) {
      const channel = await interaction.guild.channels.fetch(citation.channelId).catch(() => null);
      const msg = channel?.isTextBased() ? await channel.messages.fetch(citation.messageId).catch(() => null) : null;
      if (msg) {
        const embed = EmbedBuilder.from(msg.embeds[0]).setColor(COLORS.WARNING).setTitle(`🚨 ~~Trafik Cezası #${citationNumber}~~ (İPTAL EDİLDİ)`);
        await msg.edit({ embeds: [embed] }).catch(() => null);
      }
    }

    await interaction.reply({
      embeds: [successEmbed('Ceza İptal Edildi', `Trafik cezası #${citationNumber} iptal edildi.`)],
      ephemeral: true,
    });

    await logToGuildChannel(interaction.guild, guildConfig, {
      title: '🚨 Trafik Cezası İptal Edildi',
      description: `#${citationNumber} iptal edildi (${interaction.user})`,
      color: COLORS.WARNING,
    });
  },

  async historyCitation(interaction) {
    const targetUser = interaction.options.getUser('uye', true);
    const citations = await Citation.find({ guildId: interaction.guildId, targetId: targetUser.id }).sort({ createdAt: -1 }).limit(15);

    if (citations.length === 0) {
      return interaction.reply({ embeds: [infoEmbed('Kayıt Yok', `${targetUser} adına kayıtlı ceza bulunamadı.`)], ephemeral: true });
    }

    const totalActive = citations.filter((c) => !c.voided).reduce((sum, c) => sum + c.fineAmount, 0);

    const embed = infoEmbed(
      `Ceza Geçmişi — ${targetUser.username}`,
      citations
        .map(
          (c) =>
            `**#${c.citationNumber}** ${c.voided ? '~~' : ''}${c.violation} — ${c.currency}${c.fineAmount.toLocaleString()}${c.voided ? '~~ (iptal)' : ''}`
        )
        .join('\n')
    ).addFields({ name: 'Toplam (aktif cezalar)', value: `${citations[0].currency}${totalActive.toLocaleString()}` });

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
