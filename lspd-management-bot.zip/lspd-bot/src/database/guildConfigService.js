'use strict';

const GuildConfig = require('./models/GuildConfig');

// Short-lived in-memory cache to avoid a DB round trip on every single
// interaction. Any write path calls invalidate() so state is never stale
// for longer than a single in-flight request.
const cache = new Map(); // guildId -> { doc, expiresAt }
const CACHE_TTL_MS = 30 * 1000;

async function getGuildConfig(guildId) {
  const cached = cache.get(guildId);
  if (cached && cached.expiresAt > Date.now()) return cached.doc;

  let doc = await GuildConfig.findOne({ guildId });
  if (!doc) {
    doc = await GuildConfig.create({ guildId });
  }

  cache.set(guildId, { doc, expiresAt: Date.now() + CACHE_TTL_MS });
  return doc;
}

function invalidate(guildId) {
  cache.delete(guildId);
}

/**
 * Applies a mutation function to the guild's config document, saves it, and
 * invalidates the cache. Callers pass a function that mutates the mongoose
 * document in place (no need to call .save() themselves).
 */
async function updateGuildConfig(guildId, mutateFn) {
  const doc = await getGuildConfig(guildId);
  await mutateFn(doc);
  await doc.save();
  invalidate(guildId);
  return doc;
}

module.exports = { getGuildConfig, updateGuildConfig, invalidate };
