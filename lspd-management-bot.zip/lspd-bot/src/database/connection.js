'use strict';

const mongoose = require('mongoose');
const { MONGODB_URI } = require('../config/env');

mongoose.set('strictQuery', true);

let connectingPromise = null;

/**
 * Connects to MongoDB. Safe to call multiple times — returns the same
 * in-flight/resolved promise so callers never open duplicate connections.
 */
async function connectDatabase(logger) {
  if (mongoose.connection.readyState === 1) return mongoose.connection;
  if (connectingPromise) return connectingPromise;

  connectingPromise = mongoose
    .connect(MONGODB_URI, {
      maxPoolSize: 10,
      serverSelectionTimeoutMS: 15000,
    })
    .then((conn) => {
      logger?.success('Database', 'MongoDB bağlantısı kuruldu.');
      return conn;
    })
    .catch((err) => {
      connectingPromise = null;
      logger?.error('Database', `MongoDB bağlantı hatası: ${err.message}`);
      throw err;
    });

  mongoose.connection.on('disconnected', () => {
    logger?.warn('Database', 'MongoDB bağlantısı koptu, yeniden bağlanılıyor...');
  });

  mongoose.connection.on('reconnected', () => {
    logger?.success('Database', 'MongoDB bağlantısı yeniden kuruldu.');
  });

  mongoose.connection.on('error', (err) => {
    logger?.error('Database', `MongoDB hata olayı: ${err.message}`);
  });

  return connectingPromise;
}

module.exports = { connectDatabase, mongoose };
