'use strict';

const { Schema, model } = require('mongoose');
const { LANGUAGES } = require('../../config/constants');

const RankSchema = new Schema(
  {
    roleId: { type: String, required: true },
    name: { type: String, required: true },
    order: { type: Number, required: true }, // 0 = lowest rank, ascending upward
  },
  { _id: false }
);

const GuildConfigSchema = new Schema(
  {
    guildId: { type: String, required: true, unique: true, index: true },

    language: { type: String, enum: Object.values(LANGUAGES), default: LANGUAGES.TR },

    // Ordered ascending from lowest to highest rank.
    ranks: { type: [RankSchema], default: [] },

    channels: {
      logChannel: { type: String, default: null },
      reportChannel: { type: String, default: null },
      citationChannel: { type: String, default: null },
      shiftChannel: { type: String, default: null },
      announcementChannel: { type: String, default: null },
    },

    roles: {
      moderatorRoles: { type: [String], default: [] },
      adminRoles: { type: [String], default: [] },
    },

    // Per-command role-based override. If a command name has entries here,
    // only members holding one of those roles (or admin/owner) may run it.
    commandPermissions: {
      type: Map,
      of: [String],
      default: {},
    },

    settings: {
      defaultFineCurrency: { type: String, default: '$' },
      requireReasonOnRankDown: { type: Boolean, default: true },
      shiftReminderMinutes: { type: Number, default: 0 }, // 0 = disabled
      maxActiveShiftHours: { type: Number, default: 12 },
    },

    setupCompleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = model('GuildConfig', GuildConfigSchema);
