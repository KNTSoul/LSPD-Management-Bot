'use strict';

const { Schema, model } = require('mongoose');
const { REPORT_STATUS } = require('../../config/constants');

const ReportSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    caseNumber: { type: Number, required: true },
    reporterId: { type: String, required: true },
    targetId: { type: String, required: true, index: true },
    reason: { type: String, required: true },
    evidence: { type: String, default: null },
    status: {
      type: String,
      enum: Object.values(REPORT_STATUS),
      default: REPORT_STATUS.OPEN,
    },
    resolvedById: { type: String, default: null },
    resolutionNote: { type: String, default: null },
    messageId: { type: String, default: null },
    channelId: { type: String, default: null },
  },
  { timestamps: true }
);

ReportSchema.index({ guildId: 1, caseNumber: 1 }, { unique: true });

module.exports = model('Report', ReportSchema);
