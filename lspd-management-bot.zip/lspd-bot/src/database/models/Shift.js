'use strict';

const { Schema, model } = require('mongoose');

const ShiftSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    userId: { type: String, required: true, index: true },
    startTime: { type: Date, required: true },
    endTime: { type: Date, default: null },
    durationMs: { type: Number, default: 0 },
    active: { type: Boolean, default: true },
    messageId: { type: String, default: null },
    channelId: { type: String, default: null },
    note: { type: String, default: null },
  },
  { timestamps: true }
);

ShiftSchema.index({ guildId: 1, userId: 1, active: 1 });

module.exports = model('Shift', ShiftSchema);
