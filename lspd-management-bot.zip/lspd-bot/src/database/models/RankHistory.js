'use strict';

const { Schema, model } = require('mongoose');

const RankHistorySchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    targetId: { type: String, required: true, index: true },
    actorId: { type: String, required: true },
    direction: { type: String, enum: ['up', 'down', 'set'], required: true },
    fromRoleId: { type: String, default: null },
    toRoleId: { type: String, default: null },
    fromRankName: { type: String, default: null },
    toRankName: { type: String, default: null },
    reason: { type: String, default: null },
  },
  { timestamps: true }
);

RankHistorySchema.index({ guildId: 1, targetId: 1, createdAt: -1 });

module.exports = model('RankHistory', RankHistorySchema);
