'use strict';

const { Schema, model } = require('mongoose');

const CitationSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    citationNumber: { type: Number, required: true },
    officerId: { type: String, required: true },
    targetId: { type: String, required: true, index: true },
    violation: { type: String, required: true },
    fineAmount: { type: Number, required: true, min: 0 },
    currency: { type: String, default: '$' },
    notes: { type: String, default: null },
    messageId: { type: String, default: null },
    channelId: { type: String, default: null },
    voided: { type: Boolean, default: false },
    voidedById: { type: String, default: null },
  },
  { timestamps: true }
);

CitationSchema.index({ guildId: 1, citationNumber: 1 }, { unique: true });

module.exports = model('Citation', CitationSchema);
