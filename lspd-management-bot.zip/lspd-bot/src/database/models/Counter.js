'use strict';

const { Schema, model } = require('mongoose');

const CounterSchema = new Schema({
  key: { type: String, required: true, unique: true }, // e.g. `${guildId}:report` or `${guildId}:citation`
  value: { type: Number, default: 0 },
});

const CounterModel = model('Counter', CounterSchema);

/**
 * Atomically increments and returns the next sequence number for a given key.
 * Using findOneAndUpdate with $inc + upsert avoids race conditions between
 * concurrent commands issuing citations/reports at the same time.
 */
async function getNextSequence(key) {
  const doc = await CounterModel.findOneAndUpdate(
    { key },
    { $inc: { value: 1 } },
    { new: true, upsert: true }
  );
  return doc.value;
}

module.exports = { CounterModel, getNextSequence };
