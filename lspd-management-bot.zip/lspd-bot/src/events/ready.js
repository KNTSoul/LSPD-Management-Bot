'use strict';

const { ActivityType, Events } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    logger.success('Client', `${client.user.tag} olarak giriş yapıldı. (${client.guilds.cache.size} sunucu)`);

    client.user.setPresence({
      activities: [{ name: '/setup ile yapılandır', type: ActivityType.Watching }],
      status: 'online',
    });
  },
};
