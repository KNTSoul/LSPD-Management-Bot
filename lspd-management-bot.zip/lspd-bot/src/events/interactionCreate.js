'use strict';

const { Events } = require('discord.js');
const { safeExecute } = require('../utils/errorHandler');
const { handleInteraction: handleSetupInteraction } = require('../utils/setupWizard');
const { errorEmbed } = require('../utils/embeds');
const logger = require('../utils/logger');

const SETUP_PREFIXES = ['setup_'];

function isSetupInteraction(interaction) {
  const id = interaction.customId;
  if (!id) return false;
  return SETUP_PREFIXES.some((prefix) => id.startsWith(prefix));
}

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction) {
    // --- Slash commands ------------------------------------------------
    if (interaction.isChatInputCommand()) {
      const command = interaction.client.commands.get(interaction.commandName);
      if (!command) {
        logger.warn('Interaction', `Bilinmeyen komut çalıştırılmaya çalışıldı: ${interaction.commandName}`);
        return interaction.reply({
          embeds: [errorEmbed('Komut Bulunamadı', 'Bu komut artık mevcut değil. Lütfen komutları yeniden yükleyin.')],
          ephemeral: true,
        });
      }

      if (!interaction.inGuild()) {
        return interaction.reply({
          embeds: [errorEmbed('Sunucu Gerekli', 'Bu bot yalnızca sunucular içinde kullanılabilir.')],
          ephemeral: true,
        });
      }

      return safeExecute(interaction, () => command.execute(interaction), `Command:${interaction.commandName}`);
    }

    // --- Setup wizard components & modals -------------------------------
    if (
      (interaction.isMessageComponent() || interaction.isModalSubmit()) &&
      isSetupInteraction(interaction)
    ) {
      return safeExecute(interaction, () => handleSetupInteraction(interaction), 'SetupWizard');
    }

    // --- Autocomplete -----------------------------------------------------
    if (interaction.isAutocomplete()) {
      const command = interaction.client.commands.get(interaction.commandName);
      if (!command?.autocomplete) return;
      try {
        await command.autocomplete(interaction);
      } catch (err) {
        logger.error('Autocomplete', err.stack || err.message);
      }
    }
  },
};
