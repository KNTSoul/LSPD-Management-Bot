'use strict';

const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

function loadEvents(client) {
  const eventsDir = path.join(__dirname, '..', 'events');
  const files = fs.readdirSync(eventsDir).filter((f) => f.endsWith('.js'));

  for (const file of files) {
    const filePath = path.join(eventsDir, file);
    delete require.cache[require.resolve(filePath)];
    const event = require(filePath);

    if (!event?.name || typeof event.execute !== 'function') {
      logger.warn('EventHandler', `Geçersiz event dosyası atlandı: ${file}`);
      continue;
    }

    if (event.once) {
      client.once(event.name, (...args) => event.execute(...args, client));
    } else {
      client.on(event.name, (...args) => event.execute(...args, client));
    }
  }

  logger.success('EventHandler', `${files.length} event yüklendi.`);
}

module.exports = { loadEvents };
