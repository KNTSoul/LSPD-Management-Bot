'use strict';

const fs = require('fs');
const path = require('path');
const { Collection } = require('discord.js');
const logger = require('../utils/logger');

function walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  let files = [];
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files = files.concat(walk(fullPath));
    } else if (entry.isFile() && entry.name.endsWith('.js')) {
      files.push(fullPath);
    }
  }
  return files;
}

/**
 * Loads every command module under src/commands, validates its shape, and
 * registers it on client.commands. Throws on malformed commands rather than
 * silently skipping them — a broken command should be visible at boot time.
 */
function loadCommands(client) {
  client.commands = new Collection();
  const commandsDir = path.join(__dirname, '..', 'commands');
  const files = walk(commandsDir);

  for (const file of files) {
    delete require.cache[require.resolve(file)];
    const command = require(file);

    if (!command?.data || typeof command.execute !== 'function') {
      logger.warn('CommandHandler', `Geçersiz komut dosyası atlandı: ${file}`);
      continue;
    }

    client.commands.set(command.data.name, command);
  }

  logger.success('CommandHandler', `${client.commands.size} komut yüklendi.`);
  return client.commands;
}

/**
 * Returns raw JSON payloads for command registration (used by deploy-commands.js).
 */
function getCommandDefinitions(client) {
  return [...client.commands.values()].map((cmd) => cmd.data.toJSON());
}

module.exports = { loadCommands, getCommandDefinitions, walk };
