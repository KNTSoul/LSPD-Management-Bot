'use strict';

const { REST, Routes } = require('discord.js');
const env = require('./config/env');
const logger = require('./utils/logger');
const { loadCommands, getCommandDefinitions } = require('./handlers/commandHandler');

// A lightweight fake client is enough for loadCommands, which only needs
// a `.commands` Collection to populate.
const fakeClient = {};
loadCommands(fakeClient);
const body = getCommandDefinitions(fakeClient);

const rest = new REST().setToken(env.DISCORD_TOKEN);

(async () => {
  try {
    logger.info('Deploy', `${body.length} komut kaydediliyor...`);

    if (env.DEV_GUILD_ID) {
      await rest.put(Routes.applicationGuildCommands(env.CLIENT_ID, env.DEV_GUILD_ID), { body });
      logger.success('Deploy', `Komutlar geliştirme sunucusuna (${env.DEV_GUILD_ID}) anında kaydedildi.`);
    } else {
      await rest.put(Routes.applicationCommands(env.CLIENT_ID), { body });
      logger.success('Deploy', 'Komutlar global olarak kaydedildi (yayılması ~1 saat sürebilir).');
    }
  } catch (err) {
    logger.error('Deploy', err.stack || err.message);
    process.exit(1);
  }
})();
