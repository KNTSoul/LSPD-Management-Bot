'use strict';

const { Client, GatewayIntentBits, Partials } = require('discord.js');
const env = require('./config/env');
const logger = require('./utils/logger');
const { connectDatabase } = require('./database/connection');
const { loadCommands } = require('./handlers/commandHandler');
const { loadEvents } = require('./handlers/eventHandler');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
  ],
  partials: [Partials.GuildMember, Partials.Channel],
});

async function bootstrap() {
  logger.info('Bootstrap', 'LSPD Management Bot başlatılıyor...');

  await connectDatabase(logger);
  loadCommands(client);
  loadEvents(client);

  await client.login(env.DISCORD_TOKEN);
}

process.on('unhandledRejection', (err) => {
  logger.error('Process', `Yakalanmamış Promise reddi: ${err?.stack || err}`);
});

process.on('uncaughtException', (err) => {
  logger.error('Process', `Yakalanmamış istisna: ${err?.stack || err}`);
});

bootstrap().catch((err) => {
  logger.error('Bootstrap', `Başlatma başarısız: ${err.stack || err.message}`);
  process.exit(1);
});
